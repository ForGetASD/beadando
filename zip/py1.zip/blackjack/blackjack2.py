import random

def kezdokez():
    jatekoskez = []
    osztokez = []
    for i in range(2):
        jatekoskez.append(random.randint(2, 11))
        osztokez.append(random.randint(2, 11))
    return jatekoskez, osztokez

jatekoskez, osztokez = kezdokez()

def huzas(jatekososszeg, osztoosszeg):
    SoH = ""
    while jatekososszeg <= 21 or osztoosszeg < 16:
        print("Osztó lapjai: ", osztokez)
        print("Játékos lapjai: ", jatekoskez)
        jatekososszeg = j_osszeg()
        print("Játékos lapjainak összege: ", jatekososszeg)
        print("Szeretnél húzni még lapot? Igen - Nem")
        SoH = input(": ")
        if SoH == "Igen" and jatekososszeg < 21:
            jatekoskez.append(random.randint(2, 11))
            jatekososszeg = j_osszeg()
            if jatekososszeg > 21:
                aszvaltas(jatekososszeg, osztoosszeg)
        else:
            while osztoosszeg < 16:
                osztokez.append(random.randint(2, 11))
                osztoosszeg = o_osszeg()
                if osztoosszeg > 21:
                    aszvaltas(jatekososszeg, osztoosszeg)
            break

def j_osszeg():
    jatekososszeg = 0
    for i in range(len(jatekoskez)):
        jatekososszeg += jatekoskez[i]
    return jatekososszeg

def o_osszeg():
    osztoosszeg = 0
    for i in range(len(osztokez)):
       osztoosszeg += osztokez[i]
    return osztoosszeg

def aszvaltas(jatekososszeg, osztoosszeg):
    if jatekososszeg > 21:
        for i in range(len(jatekoskez)):
            if jatekoskez[i] == 11:
                jatekoskez[i] = 1
                jatekososszeg -= 10
    else:
        for i in range(len(osztokez)):
            if osztokez[i] == 11:
                osztokez[i] = 1
                osztoosszeg -= 10
                
def jatekgyoztes(jatekososszeg, osztoosszeg):
    gyoztes = 10
    jatekososszeg = j_osszeg()
    osztoosszeg = o_osszeg()
    if jatekososszeg == 21 and len(jatekoskez) == 2:
        gyoztes = 2
    elif osztoosszeg == 21 and len(osztokez) == 2:
        gyoztes = 3
    elif jatekososszeg > 21:
        gyoztes = 4
    elif osztoosszeg > 21:
        gyoztes = 5
    elif jatekososszeg > osztoosszeg:
        gyoztes = 1
    elif jatekososszeg < osztoosszeg:
        gyoztes = 0
    return gyoztes

def jatek():
    jatekososszeg = 0
    osztoosszeg = 0
    huzas(jatekososszeg, osztoosszeg)
    jatekososszeg = j_osszeg()
    osztoosszeg = o_osszeg()
    print("------------------------------------------")
    print("-----------------Eredmény-----------------")
    print(f"Az osztónak a lapjai: {osztokez} \n A osztó lapjainak összege: {osztoosszeg}")
    print(f"A játékosnak a lapjai: {jatekoskez} \n A játékos lapjainak összege: {jatekososszeg}")
    gyoztes = jatekgyoztes(jatekososszeg, osztoosszeg)
    if gyoztes == 2:
        print("A játékos nyert blackjackel.")
    elif gyoztes == 3:
        print("Az osztó nyert blackjackel.")
    elif gyoztes == 1:
        print("A játékosnak a lapjainak összege nagyobb így a játékos nyert.")
    elif gyoztes == 0:
        print("Az osztónak a lapjainak összege nagyobb így az osztó nyert.")
    elif gyoztes == 4:
        print("A játkos besokalt így az osztó nyert.")
    elif gyoztes == 5:
        print("Az osztó besokalt így a játékos nyert.")
    print("------------------------------------------")
    osztokez.clear()
    jatekoskez.clear()
  