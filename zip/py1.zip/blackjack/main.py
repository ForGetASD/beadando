import blackjack2

#jatek = True
#while jatek == True:
blackjack2.jatek()
    #print("Szeretnél még egyet játszani? Igen - Nem")
    #valasz = input(": ")
    #if valasz == "Igen":
        #jatek = True
    #elif valasz == "Nem":
        #jatek = False
    #print()