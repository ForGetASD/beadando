import beolvasas

beolvasas.letrehoz_txt()
beolvasas.feldolgozas()