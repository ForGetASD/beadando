class Gyumolcs:
    def __init__(self, nev, szin, e_szint, t_helye):
        self.nev = nev
        self.szin = szin
        self.e_szint = int(e_szint)
        self.t_helye = t_helye.replace("\n", "")