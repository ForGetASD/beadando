import osztaly

p_lista =[]
# txt file létrehozása
def letrehoz_txt():
    f = open("gyumolcs.txt", "w", encoding="utf8")
    f.write("név*szín*édességi szint*termés\n")
    f.write("körte*zöld*4*fa\n")
    f.write("ribizli*piros*2*bokor\n")
    f.write("boróka*bordó*2*bokor\n")
    f.write("alma*piros*3*fa\n")
    f.close()

def feldolgozas():
    f = open("gyumolcs.txt", "r", encoding="utf8")
    f.readline()
    # jelenleg a 3. sorra mutat a kurzor
    # a maradék összes adatot beolvassa és eltárolja egy listában
    er_lista = f.readlines()
    #print(er_lista)
    f.close()
    for elem in er_lista:
        d_lista = elem.split("*")
        peldany = osztaly.Gyumolcs(d_lista[0], d_lista[1], d_lista[2], d_lista[3])
        #print(peldany.nev)
        p_lista.append(peldany)
    print(p_lista[2].szin)

