package hu.szit.egyszamjatek;

public class Tipp 
{
    String nev;
    int[] tippek;
}
