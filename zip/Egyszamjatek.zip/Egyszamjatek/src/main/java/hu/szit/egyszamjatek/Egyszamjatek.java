package hu.szit.egyszamjatek;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Egyszamjatek 
{
    int sorszam;
    ArrayList<Tipp> tippLista = new ArrayList<>();
    
    public void feladat02()
    {
        try {
            tryFeladat02();
        } catch (FileNotFoundException e) {
            System.err.println("Hiba! A fájl nem található!");
        }
    }
    public void tryFeladat02() throws FileNotFoundException
    {
        FileReader fr = new FileReader("egyszamjatek.txt");
        Scanner sc = new Scanner(fr);
        
        while(sc.hasNext())
        {
            String sor = sc.nextLine();
            String tomb[] = sor.split(" ");
            Tipp tipp = new Tipp();
            tipp.nev = tomb[0];
            tipp.tippek[0] = Integer.parseInt(tomb[1]);
            tipp.tippek[1] = Integer.parseInt(tomb[2]);
            tipp.tippek[2] = Integer.parseInt(tomb[3]);
            tipp.tippek[3] = Integer.parseInt(tomb[4]);
            tippLista.add(tipp);
            
            
            System.out.println(sor);
        }
    }
    public void feladat03() 
    {
        System.out.println("");
    }
    public void feladat04() 
    {
        System.out.println("");
        Scanner sc = new Scanner(System.in);
        sorszam = sc.nextInt();
    }
    public void feladat05() 
    {
        System.out.println("");
    }
    public static void main(String[] args) 
    {
        Egyszamjatek e = new Egyszamjatek();
        e.feladat02();
        e.feladat03();
        e.feladat04();
        e.feladat05();
    }
    
}
