package ikt_projekt_masodik;

import java.util.Random;

public class IKT_projekt_masodik {
    public static void main(String[] args) {
        Random rnd = new Random();
        int osszeg = 0;
        int egyes = 0;
        int kettes = 0;
        int harmas = 0;
        int negyes = 0;
        int otos = 0;
        int hatos = 0;
        int dobas = 0;
        //int ujradobas = 0;
        //int kulonbseg = 0;
        boolean szazegyenlo;
        boolean elofordult = false;
        int sorszam = 0;
        String parossorszamok = "";
        int[] sorozat = new int[6];
        
        while(osszeg < 100){
            dobas = rnd.nextInt(6)+1;
            //System.out.println(dobas);
            sorozat[0] = sorozat[1];
            sorozat[1] = sorozat[2];
            sorozat[2] = sorozat[3];
            sorozat[3] = sorozat[4];
            sorozat[4] = sorozat[5];
            sorozat[5] = dobas;
            if (sorozat[0] == 1 && sorozat[1] == 2 && sorozat[2] == 3 && sorozat[3] == 4 && sorozat[4] == 5 && sorozat[5] == 6){
                elofordult = true;
            }
            osszeg = osszeg + dobas;
            if (osszeg <= 100) {
                szazegyenlo = true;
            }else{
                szazegyenlo = false;
                osszeg = osszeg - dobas;
                System.out.println("Ez a dobás már túlhaladta a 100-at: " + dobas);
            }
            if(szazegyenlo == true){
                /*
                if(dobas == 1){
                    egyes = egyes + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                }
                else if(dobas == 2){
                    kettes = kettes + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                    parossorszamok = parossorszamok + sorszam + ", ";
                }
                else if(dobas == 3){
                    harmas = harmas + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                }
                else if(dobas == 4){
                    negyes = negyes + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                    parossorszamok = parossorszamok + sorszam + ", ";
                }
                else if(dobas == 5){
                    otos = otos + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                }
                else if(dobas == 6){
                    hatos = hatos + 1;
                    sorszam++;
                    System.out.println(sorszam+ ". " + dobas);
                    parossorszamok = parossorszamok + sorszam + ", ";
                }
                */
                switch(dobas){
                    case 1 :
                        egyes = egyes + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas); break;
                    case 2 :
                        kettes = kettes + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas);
                        parossorszamok = parossorszamok + sorszam + ", "; break;
                    case 3 :
                        harmas = harmas + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas); break;
                    case 4 :
                        negyes = negyes + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas);
                        parossorszamok = parossorszamok + sorszam + ", "; break;
                    case 5 :
                        otos = otos + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas); break;
                    case 6 :
                        hatos = hatos + 1;
                        sorszam++;
                        System.out.println(sorszam+ ". " + dobas);
                        parossorszamok = parossorszamok + sorszam + ", "; break;
                }    
            }
        }
        int[] szamok = new int[6];
        szamok[0] = egyes;
        szamok[1] = kettes;
        szamok[2] = harmas;
        szamok[3] = negyes;
        szamok[4] = otos;
        szamok[5] = hatos;
        int max = egyes;
        String szam = "1";
        for (int i = 1; i < szamok.length; i++) {
            if (szamok[i] == max) {
                szam = szam + " " + Integer.toString(i+1);
            }
            if(szamok[i] > max){
                max = szamok[i];
                szam = Integer.toString(i+1);
            }
        }
        String szoveg = "A program lefutása alatt nem fordult 1,2,3,4,5,6-os sorozat.";
        if (elofordult == true) {
            szoveg = "A program lefutása alatt előfordult 1,2,3,4,5,6-os sorozat.";
        }
        /*if(osszeg > 100){
            kulonbseg = osszeg - 100;
            osszeg = osszeg - kulonbseg;
        }
        else if(osszeg < 100){
            kulonbseg = 100 - osszeg;
            osszeg = osszeg + kulonbseg;
        }*/
            System.out.println("");
            System.out.println("A figyelembe vett számok végső összege: " + osszeg);
            /*
                System.out.println(egyes+"db egyes van");
                System.out.println(kettes+"db kettes van");
                System.out.println(harmas+"db hármas van");
                System.out.println(negyes+"db négyes van");
                System.out.println(otos+"db ötös van");
                System.out.println(hatos+"db hatos van");
            */
            System.out.println("");
            System.out.println("1 feladat.: (Hányszor fordult elő a 4-es szám): " + negyes);
            System.out.println("");
            System.out.println("2 feladat.: (Előfordult e a dobott számok sorozatában 1,2,3,4,5,6?): " + szoveg);
            System.out.println("");
            System.out.println("3 feladat.: (Hányadik sorszámmal fordultak elő a páros számok?): " + parossorszamok);
            System.out.println("");
            System.out.printf("4 feladat.: (Melyik szám hányszor fordul elő?):\n1-es számok előfordulása: %d\n2-es számok előfordulása: %d\n3-as számok előfordulása: %d\n4-es számok előfordulása: %d\n5-ös számok előfordulása: %d\n6-os számok előfordulása: %d\n",egyes,kettes,harmas,negyes,otos,hatos);
            System.out.println("");
            System.out.println("5 feladat.: (Melyik számok fordultak elő legtöbbször?): " + szam);
    }
}