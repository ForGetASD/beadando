# globális lista létrehozása
diak_lista =[]
import diakok

def file_letrehoz(utvonal="proba.txt"):
    f = open(utvonal, "w", encoding="utf8")
    f.write("Vitay Zalán\n")
    f.write("SZFB\n")
    f.close()


def kiegeszit():
    f = open("proba.txt", "r", encoding="utf8")
    #f.write("Életkor: 21")
    #f.close()
    #print(f.readlines())
    #print(f.read(5))
    f.seek(13)
    print(f.readline())

def masodikfel():
    f = open("masodik.txt", "w+", encoding="utf8")
    f.write("Vitay Zalán\n")
    f.write("SZFB\n")
    f.write("Olymindegy\n")
    #f.close()
    print(f.readline())
    f.write("Spongyabob")
    #f.close()
    f.seek(0)
    print(f.read())

def harmadikfel():
    f = open("hamrmadik.txt", "w+", encoding="utf8")
    f.write("Ady Endre: Párisban járt az Ősz\n")
    f.write("Párisba tegnap beszökött az Ősz.\n")
    f.write("Szent Mihály útján suhant nesztelen\n")
    f.write("Kánikulában,")
    f.write("halk ")
    f.write("lombok ")
    f.write("alatt\n")
    f.write("S ")
    f.write("találkozott ")
    f.write("velem.")
    f.seek(32)
    print(f.read())

def negyedikfel():
    kecske = open("kecske.txt", "w+", encoding="utf8")
    kecske.write("fantastique\nerőszak\nAtiss\nÉdesanya\nÉdesapám\nMinden\nnapja")
    kecske.seek(0)
    print(kecske.readlines())

def file_letrehoz2(utvonal="osztaly.txt"):
    f = open(utvonal, "w", encoding="utf8")
    f.write("Név/Évfolyam/Átlag\n")
    f.write("Gipsz Jakab/1/4,5\n")
    f.write("Pán Péter/2/3,6\n")
    f.close()

def lista_letrehoz():
    # beolvasom a file tartalmát
        # megnyitom olvasasra
    f = open("osztaly.txt", "r", encoding="utf8")
        # első sor beolvasása, átugrik a másodikra
    f.readline()
        # többi beolvasása
    eredeti_lista = f.readlines()
    # lista elemeinek a felszabdalása
    #for i in range(len(eredeti_lista)):
        #darabok = eredeti_lista[i].split("/")
    for elem in eredeti_lista:
        darabok = elem.split("/")
    # példányok létrehozása a már felszabdalt adatokkal
        diak = diakok.Diak(darabok[0], darabok[1], darabok[2])
    # példányokat beletesszük a listába
    diak_lista.append(diak)
    print(diak_lista[0].nev)
    #prog tételek alkalmazása