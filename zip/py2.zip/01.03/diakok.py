class Diak:
    def __init__(self, nev, evfolyam, atlag):
        self.nev = nev
        self.evfolyam = int(evfolyam)
        self.atlag = float(atlag.replace(",","."))