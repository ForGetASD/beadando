import file

# file.file_letrehoz("proba2.txt")
# file.kiegeszit()
# file.masodikfel()
# file.harmadikfel()
#file.negyedikfel()
file.file_letrehoz2()
file.lista_letrehoz()