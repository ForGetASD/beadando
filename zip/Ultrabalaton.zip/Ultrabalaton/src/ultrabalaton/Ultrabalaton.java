package ultrabalaton;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Ultrabalaton {

    public static void main(String[] args) throws FileNotFoundException {
        File input = new File("ub2017egyeni.txt");
        Scanner sc = new Scanner(input);
        
        
        int szamlalo = 0;
        sc.nextLine(); //fejléc
        while(sc.hasNextLine())
        {
            sc.nextLine();
            szamlalo++;
        }
        sc.close();
        
        sc = new Scanner(input);
        sc.nextLine();
        adatok[] adat = new adatok[szamlalo];
        
        for (int i = 0; i < adat.length; i++) {
            String[] x = sc.nextLine().split(";");
            adat[i] = new adatok(x[0], Integer.valueOf(x[1]), x[2], x[3], Integer.valueOf(x[4]));
        }
        sc.close();
        
        //3 feladat
        System.out.println("3. feladat: Egyéni indulók: "+szamlalo+" fő");
        
        //4 feladat
        int nodb = 0;
        for (int i = 0; i < adat.length; i++) {
            if (adat[i].kategoria.equals("Noi") && adat[i].tavszazalek==100) {
                nodb++;
            }
        }
        System.out.println("4. feladat: Célba érkező női sportolók: "+nodb+" fő");
        
        //5 feladat
        System.out.print("5. feladat: Kérem a sportoló nevét: ");
        sc = new Scanner(System.in);
        String versenyzo = sc.nextLine();

        
        for (int i = 0; i < adat.length; i++) {
            if (adat[i].nev.equals(versenyzo)) {
                if (adat[i].tavszazalek == 100) {
                    System.out.println("\tIndult egyéniben a sportoló? Igen");
                    System.out.println("\tTeljesítette a teljes távot? Igen");
                    break;
                }
                else{
                    System.out.println("\tIndult egyéniben a sportoló? Igen");
                    System.out.println("\tUtasi Teljesítette a teljes távot? Nem");
                    break;
                }
            }
        }
        
        //7 feladat
        System.out.print("7. Feladat");
   }
}
