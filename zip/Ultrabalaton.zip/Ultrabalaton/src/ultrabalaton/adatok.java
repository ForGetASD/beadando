package ultrabalaton;
public class adatok {
    public String nev;
    public int rajtszam;
    public String kategoria;
    public String idoeredmeny;
    public int tavszazalek;

    public adatok(String nev, int rajtszam, String kategoria, String idoeredmeny, int tavszazalek) {
        this.nev = nev;
        this.rajtszam = rajtszam;
        this.kategoria = kategoria;
        this.idoeredmeny = idoeredmeny;
        this.tavszazalek = tavszazalek;
    }
    
    public void atlagidoora()
    {
        
    }
}
